package org.example;

public class BankAccount {
    String accountNumber;
    private int balanceUsd;

    public BankAccount(String accountNumber, int initialBalance) {
        this.accountNumber = accountNumber;
        this.balanceUsd = initialBalance;
    }

    public void deposit(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        balanceUsd += amount;
    }

    public void withdraw(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }
        if (amount > balanceUsd) {
            throw new IllegalArgumentException("Insufficient funds");
        }
        balanceUsd -= amount;
    }

    public int getBalanceUsd() {
        return balanceUsd;
    }

    public void transferToBank(BankAccount other, int amount) {
        this.withdraw(amount);
        other.deposit(amount);
    }
}
