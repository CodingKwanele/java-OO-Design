package org.example;

import java.util.HashMap;
import java.util.Map;

public class Bank {
    private Map<String, BankAccount> accounts;

    public Bank() {
        this.accounts = new HashMap<>();
    }

    public void addAccount(BankAccount account) {
        accounts.put(account.accountNumber, account);
    }

    public BankAccount retrieveAccount(String accountId) {
        BankAccount account = accounts.get(accountId);
        if (account == null) {
            throw new IllegalArgumentException("Account not found");
        }
        return account;
    }

    public int totalBalanceUsd() {
        return accounts.values().stream().mapToInt(BankAccount::getBalanceUsd).sum();
    }

    public void transfer(String fromAccountId, String toAccountId, int amount) {
        BankAccount fromAccount = retrieveAccount(fromAccountId);
        BankAccount toAccount = retrieveAccount(toAccountId);
        fromAccount.transferToBank(toAccount, amount);
    }
}
