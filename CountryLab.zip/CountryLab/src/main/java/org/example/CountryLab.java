package org.example;
/**
 * @AUTHOR : kwanele dladla
 * @VERSION : 23.10.1
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.List;

public class CountryLab {

    // Named constants to avoid magic numbers in code
    private static final int LONG_COUNTRY_THRESHOLD = 10;   // for countries > 10 chars
    private static final int SHORT_COUNTRY_THRESHOLD = 5;   // for countries < 5 chars
    private static final int ALL_LONGER_THAN_THRESHOLD = 3; // for checking if all > 3 chars

    /**
     * The main method orchestrates the reading of input files,
     * performing operations on a list of country names,
     * and writing results to "matches/data.txt".
     *
     * @param args command-line arguments (not used in this program)
     */
    public static void main(final String[] args) {
        // 1. Define input file path and output directory
        final Path inputFile = Paths.get("C:\\Users\\thule\\IdeaProjects\\Comp1083 Lab 8\\src\\week8countries.txt");
        final Path matchesDir = Paths.get("matches");
        final Path dataFile = matchesDir.resolve("data.txt");

        // 2. Ensure the "matches" subdirectory exists (create if it doesn't)
        try {
            if (Files.notExists(matchesDir)) {
                Files.createDirectories(matchesDir);
            }
        } catch (final IOException e) {
            System.err.println("Error creating directory: " + matchesDir);
            e.printStackTrace();
            return;
        }

        // 3. Read all lines (country names) into a list
        final List<String> countries;
        try {
            countries = Files.readAllLines(inputFile);
        } catch (final IOException e) {
            System.err.println("Error reading input file: " + inputFile);
            e.printStackTrace();
            return;
        }

        // 4. Write all results to matches/data.txt
        try (PrintWriter writer = new PrintWriter(Files.newBufferedWriter(dataFile))) {
            // Perform and write the results of various operations to the output file
            writeResults(writer, countries);
        } catch (final IOException e) {
            System.err.println("Error writing to output file: " + dataFile);
            e.printStackTrace();
        }

        System.out.println("Processing complete. Check '" + dataFile.toAbsolutePath() + "' for results.");
    }

    /**
     * Performs various operations on the list of country names
     * and writes the results to a file.
     *
     * @param writer    the {@code PrintWriter} object to write results
     * @param countries the list of country names
     */
    private static void writeResults(final PrintWriter writer, final List<String> countries) {
        // 1) Country names longer than 10 characters:
        writer.println("Country names longer than 10 characters:");
        countries.stream()
                .filter(c -> c.length() > LONG_COUNTRY_THRESHOLD)
                .forEach(writer::println);
        writer.println();

        // 2) Country names shorter than 5 characters:
        writer.println("Country names shorter than 5 characters:");
        countries.stream()
                .filter(c -> c.length() < SHORT_COUNTRY_THRESHOLD)
                .forEach(writer::println);
        writer.println();

        // 3) Country names starting with 'A':
        writer.println("Country names starting with 'A':");
        countries.stream()
                .filter(c -> c.startsWith("A"))
                .forEach(writer::println);
        writer.println();

        // 4) Country names ending with "land":
        writer.println("Country names that end with 'land':");
        countries.stream()
                .filter(c -> c.endsWith("land"))
                .forEach(writer::println);
        writer.println();

        // 5) Country names containing "United":
        writer.println("Country names containing 'United':");
        countries.stream()
                .filter(c -> c.contains("United"))
                .forEach(writer::println);
        writer.println();

        // 6) Sorted names in ascending order
        writer.println("Sorted Names (Ascending):");
        countries.stream()
                .sorted()
                .forEach(writer::println);
        writer.println();

        // 7) Sorted names in descending order
        writer.println("Sorted Names (Descending):");
        countries.stream()
                .sorted(Comparator.reverseOrder())
                .forEach(writer::println);
        writer.println();

        // 8) Unique first letters of country names
        writer.println("Unique First Letters:");
        countries.stream()
                .map(c -> c.substring(0, 1)) // first letter
                .distinct()
                .forEach(writer::println);
        writer.println();

        // 9) Total number of countries
        final long totalCount = countries.stream().count();
        writer.println("Count of Countries: " + totalCount);
        writer.println();

        // 10) Longest country name
        writer.println("Longest Country Name:");
        countries.stream()
                .max(Comparator.comparingInt(String::length))
                .ifPresent(writer::println);
        writer.println();

        // 11) Shortest country name
        writer.println("Shortest Country Name:");
        countries.stream()
                .min(Comparator.comparingInt(String::length))
                .ifPresent(writer::println);
        writer.println();

        // 12) All country names in uppercase
        writer.println("All Country Names in UPPERCASE:");
        countries.stream()
                .map(String::toUpperCase)
                .forEach(writer::println);
        writer.println();

        // 13) Countries with more than one word in the name
        writer.println("Countries with More Than One Word:");
        countries.stream()
                .filter(c -> c.contains(" "))
                .forEach(writer::println);
        writer.println();

        // 14) Map each country to its character count
        writer.println("Map Each Country to 'X: N characters':");
        countries.forEach(c -> writer.println(c + ": " + c.length() + " characters"));
        writer.println();

        // 15) Check if any country name starts with "Z"
        writer.println("Any country name starts with 'Z'?");
        final boolean anyStartsWithZ = countries.stream().anyMatch(c -> c.startsWith("Z"));
        writer.println(anyStartsWithZ);
        writer.println();

        // 16) Check if all country names are longer than 3 characters
        writer.println("All country names longer than 3 characters?");
        final boolean allLongerThan3 = countries.stream()
                .allMatch(c -> c.length() > ALL_LONGER_THAN_THRESHOLD);
        writer.println(allLongerThan3);
        writer.println();

        writer.flush();
    }
}
