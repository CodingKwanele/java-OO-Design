import java.util.List;

public class Main {
    public static void main(final String[] args)
    {
        try {
            if (args.length < 2)
            {
                System.out.println("Please provide a command and a number as command-line arguments.");
                return;
            }

            String command = args[0];
            int number;

            try {
                number = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                System.out.println("The second argument must be a valid integer.");
                return;
            }
            System.out.println("Command: " + command);
            System.out.println("Number: " + number);

            Dictionary dictionary = new Dictionary();
            final List<String> words = dictionary.words;

            if (words == null || words.isEmpty()) {
                System.err.println("The words list is empty. Please check if the 'words.txt' file is present and readable.");
                return;
            }

            Wordable words_List = (String listOfWords, int numberOfWords) -> {
                switch (listOfWords) {
                    case "concatenate":
                        return String.join("", words);
                    case "repetition":
                        StringBuilder result = new StringBuilder();
                        for (String word : words) {
                            result.append(word.repeat(numberOfWords));
                        }
                        return result.toString();
                    case "nth":
                        if (numberOfWords < 0 || numberOfWords >= words.size()) {
                            return "Index out of bounds";
                        }
                        return words.get(numberOfWords);
                    case "reverse":
                        StringBuilder reversedResult = new StringBuilder();
                        for (String word : words) {
                            reversedResult.append(new StringBuilder(word).reverse().toString());
                        }
                        return reversedResult.toString();
                    default:
                        return "";
                }
            };

            String result = dictionary.getWords(args[0], Integer.parseInt(args[1]), words_List);
            System.out.println(result);

            words.forEach(System.out::println);

            words.stream()
                    .map(Dictionary::reverseString)
                    .forEach(System.out::println);

            words.sort(Dictionary::arrangeInAlphabeticOrder);
            System.out.println("Sorted words: " + words);

            words.stream()
                    .filter(Dictionary::isLengthAboveFive)
                    .forEach(System.out::println);

        } catch (NumberFormatException e)
        {
            System.err.println("Please provide a valid number as the second command-line argument.");
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
