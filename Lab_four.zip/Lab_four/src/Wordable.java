@FunctionalInterface
public interface Wordable
{
    String createString(String s, int n);
}
