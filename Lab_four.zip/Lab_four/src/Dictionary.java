import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;


public class Dictionary
{
    List<String> words;

    public Dictionary()
    {
        try
        {
            words = Files.lines(Path.of("words.txt")).collect(Collectors.toList());
        } catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }

    public String getWords(final String command, final int number, final Wordable wordable)
    {
        return wordable.createString(command, number);
    }

    public static String reverseString(final String input)
    {
        return new StringBuilder(input).reverse().toString();
    }

    public static int arrangeInAlphabeticOrder(final String firstWord, final String secondWord)
    {
        return firstWord.compareTo(secondWord);
    }

    public static boolean isLengthAboveFive(final String word)
    {
        return word.length() > 5;
    }
}
