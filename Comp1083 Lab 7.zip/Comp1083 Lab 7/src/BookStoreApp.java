import java.util.ArrayList;
import java.util.List;

/**
 * The {@code BookStoreApp} class is the main entry point for a bookstore simulation application.
 * It demonstrates the use of generic classes, nested/inner classes, lambda expressions, 
 * anonymous classes, and the PECS (Producer Extends, Consumer Super) principle.
 */
public class BookStoreApp {

    private static final String WAR_SEARCH_QUERY = "War"; // Constant for clarity
    private static final String TITLE_SEPARATOR = " - "; // Formatting separator

    /**
     * The main method to run the bookstore application.
     *
     * @param args Command-line arguments
     */
    public static void main(String[] args) {
        // Create a BookStore that can hold ANY type of Literature (generic).
        BookStore<Literature> store = new BookStore<>();

        // Add items to the store
        store.addItem(new Novel("War and Peace"));
        store.addItem(new Novel("Pride and Prejudice"));
        store.addItem(new ComicBook("Spider-Man"));
        store.addItem(new Magazine("National Geographic"));

        // 1) Use the static nested class functionality
        System.out.println(BookStore.BookStoreInfo.getStorePolicy());
        BookStore.BookStoreInfo.printWelcomeMessage();

        // 2) Use the inner class to get novel statistics
        BookStore<Literature>.NovelStatistics stats = store.getNovelStatistics();
        System.out.println("Number of novels: " + stats.countNovels());
        stats.longestNovelTitle().ifPresent(title ->
                System.out.println("Longest novel title: " + title)
        );

        // 3) Search for items using a lambda expression
        System.out.println("\nSearching for titles containing '" + WAR_SEARCH_QUERY + "':");
        List<Literature> foundItems = store.searchByTitle(WAR_SEARCH_QUERY);
        for (Literature lit : foundItems) {
            System.out.println(TITLE_SEPARATOR + lit.getTitle());
        }

        // 4) Sort items using a method reference
        System.out.println("\nSorting items by title:");
        store.sortItemsByTitle();
        for (Literature item : store.getItems()) {
            System.out.println(item.getTitle());
        }

        // 5) Sort using an anonymous inner class (old style)
        System.out.println("\nRe-sorting (old way):");
        store.sortItemsByTitleOldWay();
        for (Literature item : store.getItems()) {
            System.out.println(item.getTitle());
        }

        // Demonstrate PECS concept with source (producer) and destination (consumer)
        System.out.println("\nUsing PECS methods:");

        // Create a source list that produces T (e.g., novels)
        List<Novel> newNovels = new ArrayList<>();
        newNovels.add(new Novel("The Great Gatsby"));
        newNovels.add(new Novel("Jane Eyre"));

        // Add the items from the source list to the store (? extends T concept)
        store.addAllItemsFrom(newNovels);

        // Create a destination list to consume items (? super T concept)
        List<Literature> destination = new ArrayList<>();
        store.copyItemsTo(destination);

        // Display the items copied to the destination
        System.out.println("Destination list after copy:");
        for (Literature literature : destination) {
            System.out.println(TITLE_SEPARATOR + literature.getTitle());
        }
    }
}