/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */

public abstract class Literature {

    private final String title;

    public Literature(final String title){
        this.title = title;
    }

    public String getTitle(){
        return title;
    }
}

