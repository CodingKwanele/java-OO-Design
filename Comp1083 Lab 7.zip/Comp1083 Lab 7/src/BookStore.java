/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */
import java.util.*;
import java.util.stream.Collectors;

/**
 * A generic BookStore that manages items of type Literature or its subclasses.
 *
 * @param <T> The type of Literature objects stored.
 */
public class BookStore<T extends Literature> {
    /**
     * List to store items of type T.
     */
    private final List<T> items;

    /**
     * Constructor to initialize the BookStore with an empty list of items.
     */
    public BookStore() {
        this.items = new ArrayList<>();
    }

    /**
     * Retrieves the list of items in the BookStore.
     *
     * @return List of items.
     */
    public List<T> getItems() {
        return items;
    }

    /**
     * Adds a single item to the BookStore.
     *
     * @param item The item to be added.
     */
    public void addItem(final T item) {
        items.add(item);
    }

    /**
     * Static nested class representing information about the BookStore.
     */
    public static class BookStoreInfo {
        /**
         * Retrieves the store's policy.
         *
         * @return A string representing the store policy.
         */
        public static String getStorePolicy() {
            return "All sales are final. No returns after 30 days.";
        }

        /**
         * Prints a welcome message to the console.
         */
        public static void printWelcomeMessage() {
            System.out.println("Welcome to our Book Store!");
        }
    }

    /**
     * Non-static inner class to calculate statistics about novels in the BookStore.
     */
    public class NovelStatistics {
        /**
         * Counts the number of novels in the BookStore.
         *
         * @return The count of novels.
         */
        public long countNovels() {
            return items.stream()
                    .filter(item -> item instanceof Novel)
                    .count();
        }

        /**
         * Finds the title of the longest novel in the BookStore.
         *
         * @return An Optional containing the title of the longest novel, or an empty Optional if none exist.
         */
        public Optional<String> longestNovelTitle() {
            return items.stream()
                    .filter(item -> item instanceof Novel)
                    .map(Literature::getTitle)
                    .max(Comparator.comparingInt(String::length));
        }
    }

    /**
     * Creates and retrieves an instance of the {@link NovelStatistics} inner class.
     *
     * @return A NovelStatistics object.
     */
    public NovelStatistics getNovelStatistics() {
        return new NovelStatistics();
    }

    /**
     * Searches for items with titles containing a specific query (case-insensitive).
     *
     * @param query The search query.
     * @return A list of items matching the search query.
     */
    public List<T> searchByTitle(final String query) {
        return items.stream()
                .filter(item -> item.getTitle().toLowerCase().contains(query.toLowerCase()))
                .collect(Collectors.toList());
    }

    /**
     * Sorts the items in the BookStore alphabetically by title using a method reference.
     */
    public void sortItemsByTitle() {
        items.sort(Comparator.comparing(Literature::getTitle));
    }

    /**
     * Sorts the items in the BookStore alphabetically by title using an anonymous inner class.
     */
    public void sortItemsByTitleOldWay() {
        Collections.sort(items, new Comparator<T>() {
            @Override
            public int compare(final T o1, final T o2) {
                return o1.getTitle().compareTo(o2.getTitle());
            }
        });
    }

    /**
     * Adds all items from a given collection to the BookStore.
     *
     * @param source The source collection containing items to be added.
     */
    public void addAllItemsFrom(final Collection<? extends T> source) {
        items.addAll(source);
    }

    /**
     * Copies all items from the BookStore to a given destination collection.
     *
     * @param destination The destination collection to which items are copied.
     */
    public void copyItemsTo(final Collection<? super T> destination) {
        destination.addAll(items);
    }
}