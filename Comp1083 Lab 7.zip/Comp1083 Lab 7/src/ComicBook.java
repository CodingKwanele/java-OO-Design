/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */
public class ComicBook extends Literature{
    public ComicBook(final String title) {
        super(title);
    }
}
