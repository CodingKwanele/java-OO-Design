/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */

public class Novel extends Literature
{
    public Novel(final String title){super(title);}
}
