/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */
public class Magazine extends Literature{
    public Magazine(final String title) {
        super(title);
    }
}
