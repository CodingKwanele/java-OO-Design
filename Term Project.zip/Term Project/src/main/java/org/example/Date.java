/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */

package org.example;

public class Date implements Orderable, Comparable<Date>
{
    private static final int MIN_MONTH = 1;
    private static final int MAX_MONTH = 12;
    private static final int INVALID_YEAR = 0;
    private static final int JANUARY = 1;
    private static final int FEBRUARY = 2;
    private static final int DECEMBER = 12;
    private static final int LEAP_YEAR_JAN_FEB_CORRECTION = 6;
    private static final int DAYS_IN_WEEK = 7;
    private static final int CENTURY_DIVISOR = 100;
    private static final int MONTHS_IN_WEEKS = 4;
    private static final int MINIMUM_DAY = 1;
    private static final int DAYS_IN_LEAP_FEBRUARY = 29;
    private static final int DEFAULT_CENTURY_CODE = 0;
    private static final int CENTURY_CODE_16 = 6;
    private static final int CENTURY_CODE_17 = 4;
    private static final int CENTURY_CODE_18 = 2;
    private static final int CENTURY_CODE_20 = 6;
    private static final int CENTURY_CODE_21 = 4;

    private static final int[] DAYS_IN_MONTH_COMMON_YEAR = {
            31, 28, 31, 30, 31, 30,
            31, 31, 30, 31, 30, 31
    };

    private static final int[] MONTH_CODES = {
            1, 4, 4, 0, 2, 5, 0, 3, 6, 1, 4, 6
    };

    private static final String[] WEEKDAYS = {
            "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"
    };

    private final int day;
    private final int month;
    private final int year;

    public Date(int day, int month, int year)
    {
        if (year == INVALID_YEAR) throw new IllegalArgumentException("invalid year");
        if (month < MIN_MONTH || month > MAX_MONTH) throw new IllegalArgumentException("invalid month");
        if (day < MINIMUM_DAY || day > getNumberOfDaysInMonth(month, year)) throw new IllegalArgumentException("invalid day of the month");

        this.day = day;
        this.month = month;
        this.year = year;
    }

    public int getDay() { return day; }
    public int getMonth() { return month; }
    public int getYear() { return year; }

    public String getYyyyMmDd()
    {
        return String.format("%04d-%02d-%02d", getYear(), getMonth(), getDay());
    }

    @Override
    public String toString()
    {
        return getYyyyMmDd();
    }

    @Override
    public Date next()
    {
        int d = getDay(), m = getMonth(), y = getYear();
        if (d < getNumberOfDaysInMonth(m, y))
        {
            d++;
        } else
        {
            d = MINIMUM_DAY;
            if (m < DECEMBER) {
                m++;
            } else {
                m = JANUARY;
                y++;
            }
        }
        return new Date(d, m, y);
    }

    @Override
    public Date previous()
    {
        int d = getDay(), m = getMonth(), y = getYear();
        if (d > MINIMUM_DAY)
        {
            d--;
        } else
        {
            if (m > MIN_MONTH)
            {
                m--;
            } else
            {
                m = DECEMBER;
                y--;
                if (y == INVALID_YEAR) throw new IllegalArgumentException("invalid year");
            }
            d = getNumberOfDaysInMonth(m, y);
        }
        return new Date(d, m, y);
    }

    @Override
    public int compareTo(Date other)
    {
        if (this.getYear() != other.getYear()) return this.getYear() - other.getYear();
        if (this.getMonth() != other.getMonth()) return this.getMonth() - other.getMonth();
        return this.getDay() - other.getDay();
    }

    public String getDayOfTheWeek()
    {
        int yLastTwo = Math.abs(getYear()) % CENTURY_DIVISOR;
        int sum = (yLastTwo / MAX_MONTH) + (yLastTwo % MAX_MONTH) + ((yLastTwo % MAX_MONTH) / MONTHS_IN_WEEKS) + getDay() + getMonthCode(getMonth());

        if ((getMonth() == JANUARY || getMonth() == FEBRUARY) && isLeapYear()) sum += LEAP_YEAR_JAN_FEB_CORRECTION;

        sum += getCenturyCode(getYear());
        return WEEKDAYS[sum % DAYS_IN_WEEK];
    }

    private int getNumberOfDaysInMonth(int month, int year)
    {
        if (month == FEBRUARY && isLeapYear(year)) return DAYS_IN_LEAP_FEBRUARY;
        return DAYS_IN_MONTH_COMMON_YEAR[month - MIN_MONTH];
    }

    private int getMonthCode(int month)
    {
        if (month < MIN_MONTH || month > MAX_MONTH) throw new IllegalArgumentException("invalid month");
        return MONTH_CODES[month - MIN_MONTH];
    }

    private int getCenturyCode(int year)
    {
        int century = year / CENTURY_DIVISOR;
        return switch (century)
        {
            case CENTURY_CODE_16, 20 -> CENTURY_CODE_20;
            case CENTURY_CODE_17, 21 -> CENTURY_CODE_17;
            case CENTURY_CODE_18 -> CENTURY_CODE_18;
            default -> DEFAULT_CENTURY_CODE;
        };
    }

    private boolean isLeapYear()
    {
        return isLeapYear(this.getYear());
    }

    private boolean isLeapYear(int year)
    {
        return (year % 400 == DEFAULT_CENTURY_CODE) || ((year % MONTHS_IN_WEEKS == DEFAULT_CENTURY_CODE) && (year % CENTURY_DIVISOR != DEFAULT_CENTURY_CODE));
    }
}
