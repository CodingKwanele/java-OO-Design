package org.example;

/**
 * Represents a student, which is a type of Person, with a student number.
 *
 * @author Kwanele Dladla
 * @version 23.10.1
 */
public class Student extends Person {
    /**
     * The student number.
     */
    private final String studentNumber;

    /**
     * The required length of the student number.
     */
    private final static int LENGTHSTUDENTNUMBER = 9;

    /**
     * Constructs a Student.
     *
     * @param born          the birthdate (must not be null)
     * @param name          the person's name (must not be null)
     * @param studentNumber must be non-null, non-blank, and exactly 9 characters long.
     * @throws IllegalPersonException with message "bad student number" if studentNumber is invalid.
     */
    public Student(Date born, Name name, String studentNumber) {
        super(born, name);
        // Check for null, blank (empty after trimming), or length not equal to 9.
        if (studentNumber == null || studentNumber.trim().isEmpty() || studentNumber.trim().length() != LENGTHSTUDENTNUMBER) {
            throw new IllegalPersonException("bad student number");
        }
        this.studentNumber = studentNumber.trim();
    }

    /**
     * Gets the student number.
     *
     * @return The student number.
     */
    public String getStudentNumber() {
        return studentNumber;
    }

    /**
     * Returns a string representation of the Student object.
     *
     * @return A string representation of the student, including their name, student number, date of birth, and date of death (if applicable).
     */
    @Override
    public String toString() {
        String prettyName = getName().getPrettyName();
        String birth = getDateOfBirth().getYyyyMmDd();
        if (isAlive()) {
            return prettyName + " (student number: " + studentNumber + ") was born " + birth + " and is still alive";
        } else {
            String death = getDateOfDeath().getYyyyMmDd();
            return prettyName + " (student number: " + studentNumber + ") was born " + birth + " and died " + death;
        }
    }
}