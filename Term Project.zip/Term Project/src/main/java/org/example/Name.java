/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */


package org.example;

public class Name
{
    // Create the Final instance variables
    private final String first;
    private final String last;

    /**
     * Constructs a Name object with first and last names.
     * @param first the first name; must not be null or blank.
     * @param last the last name; must not be null or blank.
     * @throws IllegalArgumentException if first is null/blank or last is null/blank.
     */
    public Name(final String first,final String last)
    {
        if (first == null || first.trim().isEmpty()) {
            throw new IllegalArgumentException("invalid first name");
        }
        if (last == null || last.trim().isEmpty()) {
            throw new IllegalArgumentException("invalid last name");
        }
        this.first = first.trim();
        this.last = last.trim();
    }

    public String getFirst() {
        return first;
    }

    public String getLast() {
        return last;
    }

    /**
     * Returns the initials in the format "F.L.".
     * @return the initials of the name.
     */
    public String getInitials() 
    {
        return Character.toUpperCase(getFirst().charAt(0)) + "." + Character.toUpperCase(getLast().charAt(0)) + ".";
    }

    /**
     * Returns the formatted full name with proper capitalization.
     * @return the formatted full name.
     */
    public String getPrettyName()
    {
        return capitalize(getFirst()) + " " + capitalize(getLast());
    }

    /**
     * Capitalizes the first letter of the string and makes the rest lowercase.
     * @param s the string to capitalize.
     * @return the capitalized string.
     */
    private String capitalize(final String s)
    {
        if (s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
    }
}
