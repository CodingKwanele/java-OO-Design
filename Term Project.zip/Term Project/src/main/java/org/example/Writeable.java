/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */
package org.example;

@FunctionalInterface
public interface Writeable
{
    void printData(final String s, final int min, final int max);
}
