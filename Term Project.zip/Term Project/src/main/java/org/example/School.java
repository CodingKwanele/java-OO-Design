/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */

package org.example;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a school with a list of registered people.
 */
public class School {
    /**
     * The list of registered people in the school.
     */
    private List<Person> people;

    /**
     * The current year.
     */
    private static final int CURRENT_YEAR = 2022;

    /**
     * Initializes the list of people.
     */
    {
        people = new ArrayList<>();
    }

    /**
     * Prints the roster of all registered people.
     */
    public void printRoster() {
        people.forEach(System.out::println);
    }

    /**
     * Registers a new person to the school.
     *
     * @param p The person to register.
     * @throws IllegalPersonException If the person is null.
     */
    public void register(Person p) {
        if (p == null) {
            throw new IllegalPersonException("Cannot Register a Non-Person. ");
        }
        people.add(p);
    }

    /**
     * Prints each person's age for every year of their life from their birth until the current year (if alive)
     * or their year of death (if deceased) using a Writeable lambda.
     */
    public void printAgesAndYears() {
        Writeable w = (fullName, yearBorn, maxYear) -> {
            for (int year = yearBorn; year < maxYear; year++) {
                int age = year - yearBorn;
                System.out.println(fullName + ": " + year + " (age " + age + ")");
            }
        };

        for (Person p : people) {
            String fullName = p.getName().getPrettyName();
            int yearBorn = p.getDateOfBirth().getYear();
            int maxYear = p.isAlive() ? CURRENT_YEAR : p.getDateOfDeath().getYear();
            // Pass maxYear + 1 because the lambda loops until (but not including) the upper bound.
            w.printData(fullName, yearBorn, maxYear + 1);
        }
    }

    /**
     * Saves the details of all registered people to "people.txt" in the required format.
     *
     * @throws IOException If an I/O error occurs.
     */
    public void saveDetails() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("people.txt"))) {
            for (Person p : people) {
                StringBuilder sb = new StringBuilder();
                String prettyName = p.getName().getPrettyName();
                String initials = p.getName().getInitials();
                String birthDayOfWeek = p.getDateOfBirth().getDayOfTheWeek();
                String birthDate = p.getDateOfBirth().getYyyyMmDd();
                sb.append(prettyName)
                        .append(" (").append(initials).append(") was born on ")
                        .append(birthDayOfWeek).append(" ").append(birthDate);
                if (!p.isAlive()) {
                    String deathDayOfWeek = p.getDateOfDeath().getDayOfTheWeek();
                    String deathDate = p.getDateOfDeath().getYyyyMmDd();
                    sb.append(" and died on ").append(deathDayOfWeek).append(" ").append(deathDate);
                }
                sb.append(".");
                writer.write(sb.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}