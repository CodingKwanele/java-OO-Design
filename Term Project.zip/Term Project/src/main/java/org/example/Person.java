package org.example;

/**
 * Represents a person with a name, date of birth, and optional date of death.
 * Implements the Comparable interface to allow comparison based on date of birth.
 *
 * @author Kwanele Dladla
 * @version 23.10.1
 */
public class Person implements Comparable<Person> {
    /**
     * The date of birth of the person.
     */
    private final Date born;

    /**
     * The date of death of the person, or null if still alive.
     */
    private Date died;

    /**
     * The name of the person.
     */
    private final Name name;

    /**
     * Constructs a new Person object with the specified date of birth and name.
     *
     * @param born The date of birth of the person.
     * @param name The name of the person.
     * @throws IllegalPersonException If the date of birth or name is null.
     */
    public Person(Date born, Name name) {
        if (born == null) {
            throw new IllegalPersonException("invalid date of birth");
        }
        if (name == null) {
            throw new IllegalPersonException("invalid name");
        }
        this.born = born;
        this.name = name;
        this.died = null;
    }

    /**
     * Sets the date of death for the person.
     *
     * @param dateOfDeath The date of death.
     */
    public void die(Date dateOfDeath) {
        this.died = dateOfDeath;
    }

    /**
     * Checks if the person is still alive.
     *
     * @return true if the person is alive, false otherwise.
     */
    public boolean isAlive() {
        return died == null;
    }

    /**
     * Gets the date of birth of the person.
     *
     * @return The date of birth.
     */
    public Date getDateOfBirth() {
        return born;
    }

    /**
     * Gets the date of death of the person.
     *
     * @return The date of death, or null if still alive.
     */
    public Date getDateOfDeath() {
        return died;
    }

    /**
     * Gets the name of the person.
     *
     * @return The name.
     */
    public Name getName() {
        return name;
    }

    /**
     * Compares this Person object with another Person object based on their date of birth.
     * Later (younger) birthdates are considered larger.
     *
     * @param other The Person object to compare with.
     * @return A negative integer, zero, or a positive integer as this object is less than, equal to, or greater than the specified object.
     */
    @Override
    public int compareTo(Person other) {
        // Later (younger) birth dates are considered larger.
        return this.born.compareTo(other.born);
    }

    /**
     * Returns a string representation of the Person object.
     *
     * @return A string representation of the person, including their name, date of birth, and date of death (if applicable).
     */
    @Override
    public String toString() {
        String prettyName = name.getPrettyName();
        String birth = born.getYyyyMmDd();
        if (isAlive()) {
            return String.format("%s was born %s and is still alive", prettyName, birth);
        } else {
            String death = died.getYyyyMmDd();
            return String.format("%s was born %s and died %s", prettyName, birth, death);
        }
    }
}