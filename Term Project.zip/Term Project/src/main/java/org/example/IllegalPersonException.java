/**
 * @author : Kwanel Dladla
 * @version : 23.10.1
 */

package org.example;

public class IllegalPersonException extends RuntimeException
{
    public IllegalPersonException(final String message)
    {
        super(message);
    }
}
