package org.example;

/**
 * Represents a teacher, which is a type of Person, with a specialty.
 *
 * @author Kwanele Dladla
 * @version 23.10.1
 */
public class Teacher extends Person {
    /**
     * The specialty of the teacher.
     */
    private static String speciality;

    /**
     * Gets the specialty of the teacher.
     *
     * @return The specialty.
     */
    public static String getSpecialty() {
        return speciality;
    }

    /**
     * Constructs a Teacher.
     *
     * @param born       The birthdate (must not be null).
     * @param name       The person's name (must not be null).
     * @param speciality The teacher's specialty (must not be null or blank).
     * @throws IllegalPersonException If the birthdate, name, or specialty is invalid.
     */
    public Teacher(Date born, Name name, final String speciality) {
        super(born, name);
        if (born == null || name == null) {
            throw new IllegalPersonException("Invalid born year and name. ");
        }
        if (speciality == null || speciality.trim().isBlank()) {
            throw new IllegalPersonException("Invalid speciality provided. ");
        }
        Teacher.speciality = speciality;
    }

    /**
     * Returns a string representation of the Teacher object.
     *
     * @return A string representation of the teacher, including their name, specialty, date of birth, and date of death (if applicable).
     */
    @Override
    public String toString() {
        String prettyName = getName().getPrettyName();
        String birth = getDateOfBirth().getYyyyMmDd();
        if (isAlive()) {
            return String.format("%s (specialty: %s) was born %s and is still alive", prettyName, speciality, birth);
        } else {
            String death = getDateOfDeath().getYyyyMmDd();
            return String.format("%s (specialty: %s) was born %s and died %s", prettyName, speciality, birth, death);
        }
    }
}