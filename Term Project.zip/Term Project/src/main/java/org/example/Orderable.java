package org.example;

/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */

public interface Orderable
{
    // Both methods are abstract by default in an interface.
    Orderable next();
    Orderable previous();

}
