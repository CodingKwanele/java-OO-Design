public class DiaryEntryException extends Exception
{
    /**
     * Constructor for DiaryEntryException with a custom error message.
     *
     * @param message the error message
     */
    public DiaryEntryException(final String message)
    {
        super(message);
    }
}

