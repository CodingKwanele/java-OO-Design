import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * version 11.09.1
 * @Author : Kwanele Dladla
 */
public class Diary {

    /**
     * Adds a new diary entry by prompting the user for date and content.
     * Writes the entry to diary.txt.
     */
    public void addEntry()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter content: ");
        String content = scanner.nextLine();

        try
        {
            DiaryEntry entry = new DiaryEntry(date, content);
            writeEntryToFile(entry);
            System.out.println("Diary entry added successfully.");
        } catch (DiaryEntryException e)
        {
            System.out.println("Error: " + e.getMessage());
        } catch (IOException e)
        {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    /**
     * Writes a diary entry to diary.txt.
     *
     * @param entry the DiaryEntry to write
     * @throws IOException if an I/O error occurs
     */
    private void writeEntryToFile(DiaryEntry entry) throws IOException
    {
        FileWriter writer = null;
        try
        {
            writer = new FileWriter("diary.txt", true);
            writer.write(entry.getDate() + "|" + entry.getContent() + "\n");
        } finally
        {
            if (writer != null)
            {
                writer.close();
            }
        }
    }

    /**
     * Displays all diary entries by reading from diary.txt.
     */
    public void viewAllEntries()
    {
        FileReader reader = null;
        Scanner scanner = null;
        try
        {
            reader = new FileReader("diary.txt");
            scanner = new Scanner(reader);
            while (scanner.hasNextLine())
            {
                String line = scanner.nextLine();
                String[] parts = line.split("\\|");
                System.out.println("Date: " + parts[0]);
                System.out.println("Content: " + parts[1]);
                System.out.println("-----");
            }
        } catch (IOException e)
        {
            System.out.println("Error reading from file: " + e.getMessage());
        } finally
        {
            if (scanner != null)
            {
                scanner.close();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e)
                {
                    System.out.println("Error closing file reader: " + e.getMessage());
                }
            }
        }
    }

    /**
     * Deletes a diary entry by date.
     * Prompts the user for the date and removes the entry from the diary file.
     */
    public void deleteEntryByDate()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter date of the entry to delete (YYYY-MM-DD): ");
        String deleteDate = scanner.nextLine();

        List<String> entries = new ArrayList<>();
        boolean entryFound = false;

        FileReader reader = null;
        Scanner fileScanner = null;
        try
        {
            reader = new FileReader("diary.txt");
            fileScanner = new Scanner(reader);
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                if (!line.startsWith(deleteDate + "|")) {
                    entries.add(line);
                } else {
                    entryFound = true;
                }
            }
        } catch (IOException e)
        {
            System.out.println("Error reading from file: " + e.getMessage());
        } finally
        {
            if (fileScanner != null)
            {
                fileScanner.close();
            }
            if (reader != null)
            {
                try
                {
                    reader.close();
                } catch (IOException e)
                {
                    System.out.println("Error closing file reader: " + e.getMessage());
                }
            }
        }

        if (entryFound)
        {
            try (FileWriter writer = new FileWriter("diary.txt"))
            {
                for (String entry : entries)
                {
                    writer.write(entry + "\n");
                }
                System.out.println("Diary entry deleted successfully.");
            } catch (IOException e)
            {
                System.out.println("Error writing to file: " + e.getMessage());
            }
        } else
        {
            System.out.println("No entry found for the given date.");
        }
    }

    /**
     * Searches for diary entries by date and displays matching entries.
     */
    public void searchEntriesByDate()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter date to search (YYYY-MM-DD): ");
        String searchDate = scanner.nextLine();

        FileReader reader = null;
        Scanner fileScanner = null;
        try {
            reader = new FileReader("diary.txt");
            fileScanner = new Scanner(reader);
            boolean found = false;
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split("\\|");
                if (parts[0].equals(searchDate))
                {
                    System.out.println("Date: " + parts[0]);
                    System.out.println("Content: " + parts[1]);
                    System.out.println("-----");
                    found = true;
                }
            }
            if (!found)
            {
                System.out.println("No entries found for the given date.");
            }
        } catch (IOException e)
        {
            System.out.println("Error reading from file: " + e.getMessage());
        } finally {
            if (fileScanner != null)
            {
                fileScanner.close();
            }
            if (reader != null)
            {
                try
                {
                    reader.close();
                } catch (IOException e)
                {
                    System.out.println("Error closing file reader: " + e.getMessage());
                }
            }
        }
    }
}
