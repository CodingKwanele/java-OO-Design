
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 * version 11.10.1
 * Author : Kwanele Dladla
 */
public class DiaryEntry
{
    private String date;
    private String content;

    /**
     * Constructor to initialize DiaryEntry with date and content.
     *
     * @param date     the date of the diary entry
     * @param content  the content of the diary entry
     * @throws DiaryEntryException if validation fails
     */
    public DiaryEntry(final String date, final String content) throws DiaryEntryException {

        setDate(date);
        setContent(content);
    }

    /**
     * Gets the date of the diary entry.
     *
     * @return the date as a String
     */
    public String getDate() {
        return date;
    }

    /**
     * Sets the date of the diary entry.
     * Validates the date format (YYYY-MM-DD) and checks if the date is valid.
     *
     * @param date the date to set
     * @throws DiaryEntryException if the date format is incorrect
     */
    public void setDate(String date) throws DiaryEntryException
    {
        if (!date.matches("\\d{4}-\\d{2}-\\d{2}"))
        {
            throw new DiaryEntryException("Invalid date format. Use YYYY-MM-DD.");
        }
        try
        {
            LocalDate.parse(date);
        } catch (DateTimeParseException e)
        {
            throw new DiaryEntryException("Invalid date. Please provide a valid date.");
        }
        this.date = date;
    }

    /**
     * Gets the content of the diary entry.
     *
     * @return the content as a String
     */
    public String getContent()
    {
        return content;
    }

    /**
     * Sets the content of the diary entry.
     * Validates that the content is non-null, non-blank, and does not contain "bcit".
     *
     * @param content the content to set
     * @throws DiaryEntryException if the content is invalid
     */
    public void setContent(String content) throws DiaryEntryException
    {
        if (content == null || content.trim().isEmpty() || content.toLowerCase().contains("bcit"))
        {
            throw new DiaryEntryException("Content cannot be null, blank, or contain 'bcit'.");
        }
        this.content = content;
    }
}
