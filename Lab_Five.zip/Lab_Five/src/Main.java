// Main.java

import java.util.Scanner;

/**
 * The Main class provides a text-based menu for the Diary application,
 * allowing users to add entries, view all entries, search by date, delete entries, or exit.
 */
public class Main
{
    public static void main(String[] args)
    {
        Diary diary = new Diary();
        Scanner scanner = new Scanner(System.in);

        while (true)
        {
            System.out.println("Diary Menu:");
            System.out.println("1. Add Entry");
            System.out.println("2. View All Entries");
            System.out.println("3. Search Entries by Date");
            System.out.println("4. Delete Entry by Date");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice;
            try
            {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e)
            {
                System.out.println("Invalid input. Please enter a number between 1 and 5.");
                continue;
            }

            switch (choice)
            {
                case 1:
                    diary.addEntry();
                    break;
                case 2:
                    diary.viewAllEntries();
                    break;
                case 3:
                    diary.searchEntriesByDate();
                    break;
                case 4:
                    diary.deleteEntryByDate();
                    break;
                case 5:
                    System.out.println("Exiting Diary...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
