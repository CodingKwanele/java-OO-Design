package java_tv;

/**
 * SpeedCounter class demonstrating the use of multiple threads to increment a counter.
 */
public class SpeedCounter {
    public static void main(String[] args) {
        Counter counter = new Counter();
        int numberOfThreads = 10;
        int incrementsPerThread = 500;

        Thread[] threads = new Thread[numberOfThreads];

        // Create and start threads
        for (int i = 0; i < numberOfThreads; i++) {
            threads[i] = new Thread(() -> {
                for (int j = 0; j < incrementsPerThread; j++) {
                    counter.increment();
                }
            });
        }

        for (Thread thread : threads) {
            thread.start();
        }

        // Wait for all threads to finish
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Print final counter value
        System.out.println("Final Count: " + counter.getCount());
    }
}
