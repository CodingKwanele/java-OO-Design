package java_tv;

import java.io.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * NumbersMagic class for reading numbers from a file
 * and separating them into even and odd numbers using streams and filters.
 */
public class NumbersMagic {

    public static void main(String[] args) {
        // Read numbers from file
        List<Integer> numbers = readNumbersFromFile("numbers.txt");

        // Separate numbers into even and odd lists
        List<Integer> evenNumbers = numbers.stream().filter(n -> n % 2 == 0).collect(Collectors.toList());
        List<Integer> oddNumbers = numbers.stream().filter(n -> n % 2 != 0).collect(Collectors.toList());

        // Print even and odd numbers
        System.out.println("Even Numbers: " + evenNumbers);
        System.out.println("Odd Numbers: " + oddNumbers);

        // Log the event
       // Logger.getInstance().log("Recorded even and odd numbers");
    }

    /**
     * Reads a list of integers from a file.
     *
     * @param fileName the name of the file to read from
     * @return a list of integers
     */
    static List<Integer> readNumbersFromFile(String fileName) {
        List<Integer> numbers = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line = br.readLine();
            if (line != null) {
                String[] parts = line.split(" ");
                for (String part : parts) {
                    numbers.add(Integer.parseInt(part));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return numbers;
    }
}
