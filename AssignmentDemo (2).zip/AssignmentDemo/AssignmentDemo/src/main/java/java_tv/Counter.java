/**
 * Counter class for concurrency example.
 * Provides synchronized increment and count retrieval methods.
 */
public class Counter {
    private int count = 0;

    public synchronized void increment() {
        count++;
    }

    public int getCount() {
        return count;
    }
}
