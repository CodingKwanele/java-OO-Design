/**
 * @author : Kwanele Dladla
 * @version : 23.10.1
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BookStore {
    private final String name;
    private final List<Novel> novels;

    private static final int FIRST_DECADE_DIGIT = 9;

    public BookStore(final String name) {
        this.name = name;
        this.novels = new ArrayList<>();

        final String[][] data =
        {
                { "The Adventures of Augie March", "Saul Bellow", "1953" },
                { "All the King’s Men", "Robert Penn Warren", "1946" },
                { "American Pastoral", "Philip Roth", "1997" },
                { "An American Tragedy", "Theodore Dreiser", "1925" },
                { "Animal Farm", "George Orwell", "1946" },
                { "Appointment in Samarra", "John O'Hara", "1934" },
                { "Are You There God? It's Me, Margaret.", "Judy Blume", "1970" },
                { "The Assistant", "Bernard Malamud", "1957" },
                { "At Swim-Two-Birds", "Flann O'Brien", "1938" },
                { "Atonement", "Ian McEwan", "2002" },
                { "Beloved", "Toni Morrison", "1987" },
                { "The Berlin Stories", "Christopher Isherwood", "1946" },
                { "The Big Sleep", "Raymond Chandler", "1939" },
                { "The Blind Assassin", "Margaret Atwood", "2000" },
                { "Blood Meridian", "Cormac McCarthy", "1986" },
                { "Brideshead Revisited", "Evelyn Waugh", "1946" },
                { "The Bridge of San Luis Rey", "Thornton Wilder", "1927" },
                { "Call It Sleep", "Henry Roth", "1935" },
                { "Catch-22", "Joseph Heller", "1961" },
                { "The Catcher in the Rye", "J.D. Salinger", "1951" },
                { "A Clockwork Orange", "Anthony Burgess", "1963" },
                { "The Confessions of Nat Turner", "William Styron", "1967" },
                { "The Corrections", "Jonathan Franzen", "2001" },
                { "The Crying of Lot 49", "Thomas Pynchon", "1966" },
                { "A Dance to the Music of Time", "Anthony Powell", "1951" },
                { "The Day of the Locust", "Nathanael West", "1939" },
                { "Death Comes for the Archbishop", "Willa Cather", "1927" },
                { "A Death in the Family", "James Agee", "1958" },
                { "The Death of the Heart", "Elizabeth Bowen", "1958" },
                { "Deliverance", "James Dickey", "1970" },
                { "Dog Soldiers", "Robert Stone", "1974" },
                { "Falconer", "John Cheever", "1977" },
                { "The French Lieutenant's Woman", "John Fowles", "1969" },
                { "The Golden Notebook", "Doris Lessing", "1962" },
                { "Go Tell It on the Mountain", "James Baldwin", "1953" },
                { "Gone with the Wind", "Margaret Mitchell", "1936" },
                { "The Grapes of Wrath", "John Steinbeck", "1939" },
                { "Gravity's Rainbow", "Thomas Pynchon", "1973" },
                { "The Great Gatsby", "F. Scott Fitzgerald", "1925" },
                { "A Handful of Dust", "Evelyn Waugh", "1934" },
                { "The Heart Is a Lonely Hunter", "Carson McCullers", "1940" },
                { "The Heart of the Matter", "Graham Greene", "1948" },
                { "Herzog", "Saul Bellow", "1964" },
                { "Housekeeping", "Marilynne Robinson", "1981" },
                { "A House for Mr. Biswas", "V.S. Naipaul", "1962" },
                { "I, Claudius", "Robert Graves", "1934" },
                { "Infinite Jest", "David Foster Wallace", "1996" },
                { "Invisible Man", "Ralph Ellison", "1952" },
                { "Light in August", "William Faulkner", "1932" },
                { "The Lion, The Witch and the Wardrobe", "C.S. Lewis", "1950" },
                { "Lolita", "Vladimir Nabokov", "1955" },
                { "Lord of the Flies", "William Golding", "1954" },
                { "The Lord of the Rings", "J.R.R. Tolkien", "1954" },
                { "Loving", "Henry Green", "1945" },
                { "Lucky Jim", "Kingsley Amis", "1954" },
                { "The Man Who Loved Children", "Christina Stead", "1940" },
                { "Midnight's Children", "Salman Rushdie", "1981" },
                { "Money", "Martin Amis", "1984" },
                { "The Moviegoer", "Walker Percy", "1961" },
                { "Mrs. Dalloway", "Virginia Woolf", "1925" },
                { "Naked Lunch", "William Burroughs", "1959" },
                { "Native Son", "Richard Wright", "1940" },
                { "Neuromancer", "William Gibson", "1984" },
                { "Never Let Me Go", "Kazuo Ishiguro", "2005" },
                { "1984", "George Orwell", "1948" },
                { "On the Road", "Jack Kerouac", "1957" },
                { "One Flew Over the Cuckoo's Nest", "Ken Kesey", "1962" },
                { "The Painted Bird", "Jerzy Kosinski", "1965" },
                { "Pale Fire", "Vladimir Nabokov", "1962" },
                { "A Passage to India", "E.M. Forster", "1924" },
                { "Play It as It Lays", "Joan Didion", "1970" },
                { "Portnoy's Complaint", "Philip Roth", "1969" },
                { "Possession", "A.S. Byatt", "1990" },
                { "The Power and the Glory", "Graham Greene", "1939" },
                { "The Prime of Miss Jean Brodie", "Muriel Spark", "1961" },
                { "Rabbit, Run", "John Updike", "1960" },
                { "Ragtime", "E.L. Doctorow", "1975" },
                { "The Recognitions", "William Gaddis", "1955" },
                { "Red Harvest", "Dashiell Hammett", "1929" },
                { "Revolutionary Road", "Richard Yates", "1961" },
                { "The Sheltering Sky", "Paul Bowles", "1949" },
                { "Slaughterhouse-Five", "Kurt Vonnegut", "1969" },
                { "Snow Crash", "Neal Stephenson", "1992" },
                { "The Sot-Weed Factor", "John Barth", "1960" },
                { "The Sound and the Fury", "William Faulkner", "1929" },
                { "The Sportswriter", "Richard Ford", "1986" },
                { "The Spy Who Came in from the Cold", "John le Carré", "1964" },
                { "The Sun Also Rises", "Ernest Hemingway", "1926" },
                { "Their Eyes Were Watching God", "Zora Neale Hurston", "1937" },
                { "Things Fall Apart", "Chinua Achebe", "1959" },
                { "To Kill a Mockingbird", "Harper Lee", "1960" },
                { "To the Lighthouse", "Virginia Woolf", "1929" },
                { "Tropic of Cancer", "Henry Miller", "1934" },
                { "Ubik", "Philip K. Dick", "1969" },
                { "Under the Net", "Iris Murdoch", "1954" },
                { "Under the Volcano", "Malcolm Lowry", "1947" },
                { "Watchmen", "Alan Moore and Dave Gibbons", "1986" },
                { "White Noise", "Don DeLillo", "1985" },
                { "White Teeth", "Zadie Smith", "2000" },
                { "Wide Sargasso Sea", "Jean Rhys", "1966" }
        };

        // Populate the ArrayList
        for (final String[] row : data) {
            final String title = row[0];
            final String author = row[1];
            final int year = Integer.parseInt(row[2]);
            novels.add(new Novel(title, author, year));
        }
    }

    // 1) printAllTitles: prints all titles in UPPERCASE
    public void printAllTitles() {
        for (final Novel n : novels) {
            System.out.println(n.getTitle().toUpperCase());
        }
    }

    // 2) printBookTitle: prints all titles that contain a given String fragment
    public void printBookTitle(final String titleFragment) {
        // Check ignoring case.
        final String fragmentLower = titleFragment.toLowerCase();
        for (final Novel n : novels) {
            if (n.getTitle().toLowerCase().contains(fragmentLower)) {
                System.out.println(n.getTitle());
            }
        }
    }

    // 3) printTitlesInAlphaOrder: prints all titles in alphabetical order (A–Z)
    public void printTitlesInAlphaOrder() {
        final List<String> titles = new ArrayList<>(); // Collect all titles into a List.
        for (final Novel n : novels) {
            titles.add(n.getTitle());
        }
        Collections.sort(titles); // Sort titles alphabetically.
        for (final String title : titles) {
            System.out.println(title);
        }
    }

    // 4) printGroupByDecade: e.g. decade=2000 means year in [2000..2009]
    public void printGroupByDecade(final int decade) {
        final int start = decade;
        final int end = decade + FIRST_DECADE_DIGIT;
        for (final Novel n : novels) {
            final int y = n.getYearPublished();
            if (y >= start && y <= end) {
                System.out.println(n.getTitle());
            }
        }
    }

    // 5) getLongest: prints the longest book title in the bookstore
    public void getLongest() {
        Novel longest = null;
        int maxLength = -1; // Initialize with a low value.
        for (final Novel n : novels) {
            final int titleLength = n.getTitle().length();
            if (titleLength > maxLength) {
                maxLength = titleLength;
                longest = n;
            }
        }
        if (longest != null) {
            System.out.println(longest.getTitle());
        }
    }

    // 6) isThereABookWrittenIn: returns true if the bookstore has a book from 'year'
    public boolean isThereABookWrittenIn(final int year) {
        for (final Novel n : novels) {
            if (n.getYearPublished() == year) {
                return true;
            }
        }
        return false;
    }

    // 7) howManyBooksContain: returns number of Books that contain 'word' in their title
    public int howManyBooksContain(final String word) {
        final String lowerCaseWord = word.toLowerCase();
        int count = 0;
        for (final Novel n : novels) {
            if (n.getTitle().toLowerCase().contains(lowerCaseWord)) {
                count++;
            }
        }
        return count;
    }

    // 8) whichPercentWrittenBetween: percentage of books between [first..last]
    public int whichPercentWrittenBetween(final int first, final int last) {
        final int totalBooks = novels.size();
        if (totalBooks == 0) return 0; // Avoid dividing by zero.
        int countInRange = 0;
        for (final Novel n : novels) {
            final int year = n.getYearPublished();
            if (year >= first && year <= last) {
                countInRange++;
            }
        }
        return (int) Math.round((countInRange * 100.0) / totalBooks);
    }

    // 9) getOldestBook: returns the Novel with the smallest yearPublished
    public Novel getOldestBook() {
        Novel oldest = null;
        int minYear = Integer.MAX_VALUE; // Initialize with the highest possible value.
        for (final Novel n : novels) {
            final int year = n.getYearPublished();
            if (year < minYear) {
                minYear = year;
                oldest = n;
            }
        }
        return oldest;
    }

    // 10) getBooksThisLength: returns all books with a title of a given length
    public List<Novel> getBooksThisLength(final int titleLength) {
        final List<Novel> results = new ArrayList<>();
        for (final Novel n : novels) {
            if (n.getTitle().length() == titleLength) {
                results.add(n);
            }
        }
        return results;
    }

    // 11) main method to test
    public static void main(final String[] args) {
        final BookStore bookstore = new BookStore("Classic Novels Collection");

        // Print the store name
        System.out.println("BookStore: " + bookstore.name);

        System.out.println("All Titles in UPPERCASE:");
        bookstore.printAllTitles();

        System.out.println("\nBook Titles Containing 'the':");
        bookstore.printBookTitle("the");

        System.out.println("\nAll Titles in Alphabetical Order:");
        bookstore.printTitlesInAlphaOrder();

        System.out.println("\nBooks from the 2000s:");
        bookstore.printGroupByDecade(2000);

        System.out.println("\nLongest Book Title:");
        bookstore.getLongest();

        System.out.println("\nIs there a book written in 1950?");
        System.out.println(bookstore.isThereABookWrittenIn(1950));

        System.out.println("\nHow many books contain 'heart'?");
        System.out.println(bookstore.howManyBooksContain("heart"));

        System.out.println("\nPercentage of books written between 1940 and 1950:");
        System.out.println(bookstore.whichPercentWrittenBetween(1940, 1950) + "%");

        System.out.println("\nOldest book:");
        final Novel oldest = bookstore.getOldestBook();
        System.out.println(oldest.getTitle() + " by " + oldest.getAuthorName() + ", " + oldest.getYearPublished());

        System.out.println("\nBooks with titles 15 characters long:");
        final List<Novel> fifteenCharTitles = bookstore.getBooksThisLength(15);
        for (final Novel n : fifteenCharTitles) {
            System.out.println(n.getTitle());
        }
    }
}