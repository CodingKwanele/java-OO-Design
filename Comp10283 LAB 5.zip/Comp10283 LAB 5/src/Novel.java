/**
 * @author : Kwanele Dladla 
 * @version : 23.10.1 
 */
public class Novel {
    private final String title;
    private final String authorName;
    private final int yearPublished;

    /**
     * Constructs a new Novel.
     *
     * @param title         The title of the novel.
     * @param authorName    The name of the author of the novel.
     * @param yearPublished The year the novel was published.
     */
    public Novel(final String title, final String authorName, final int yearPublished) {
        this.title = title;
        this.authorName = authorName;
        this.yearPublished = yearPublished;
    }

    /**
     * Gets the title of the novel.
     *
     * @return The title of the novel.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Gets the name of the author of the novel.
     *
     * @return The author's name.
     */
    public String getAuthorName() {
        return authorName;
    }

    /**
     * Gets the year the novel was published.
     *
     * @return The year of publication.
     */
    public int getYearPublished() {
        return yearPublished;
    }

    @Override
    public String toString() {
        return "Novel{" +
                "title='" + title + '\'' +
                ", authorName='" + authorName + '\'' +
                ", yearPublished=" + yearPublished +
                '}';
    }
}


