
import org.example.BookStore;
import org.example.Novel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class BookStoreTest {

    private BookStore bookstore;

    @BeforeEach
    public void setUp() {
        bookstore = new BookStore();
        bookstore.populateNovels();
    }

    @Test
    public void testPrintAllTitles() {
        // Capture the printed output
        System.out.println("------------------All Titles in UPPERCASE:-----------------------------");
        bookstore.printAllTitles();
    }

    @Test
    public void testPrintTitlesInAlphaOrder() {
        // Capture the printed output
        System.out.println("------------------Titles in Alphabetical Order:------------------------");
        bookstore.printTitlesInAlphaOrder();
    }

    @Test
    public void testGetLongest() {
        System.out.println("----------------What Book has the Longest Book Title ?---------------");
        String longestTitle = bookstore.getLongest();
        assertNotNull(longestTitle);
        System.out.println("Answer >>>>>>>>>>>" + longestTitle);
    }

    @Test
    public void testPrintGroupByDecade() {
        System.out.println("------------------ Books from the 2000s -------------------------------");
        bookstore.printGroupByDecade(2000);
    }

    @Test
    public void testPrintBookTitle() {
        System.out.println("-----------------Book Titles Containing 'the'--------------------------");
        bookstore.printBookTitle("the");
    }

    @Test
    public void testIsThereABookWrittenBetween() {
        System.out.println("----------------Is there a book written in 1950?-----------------------");
        boolean isWritten = bookstore.isThereABookWrittenBetween(1950);
        assertTrue(isWritten);
        System.out.println(isWritten);
    }

    @Test
    public void testWhichPercentWrittenBetween() {
        System.out.println("----------------Percentage of books written between 1940 and 1950------");
        double percent = bookstore.whichPercentWrittenBetween(1940, 1950);
        assertTrue(percent >= 0);
        System.out.println(percent + "%");
    }

    @Test
    public void testGetOldestBook() {
        System.out.println("----------------------------Oldest book---------------------------------");
        Novel oldest = bookstore.getOldestBook();
        assertNotNull(oldest);
        System.out.println(((Novel) oldest).getTitle() + " by " + oldest.getAuthorName() + ", " + oldest.getYearPublished());
    }

    @Test
    public void testGetBooksThisLength() {
        System.out.println("---------------------Books with titles 15 characters long------------------");
        List<Novel> fifteenCharTitles = bookstore.getBooksThisLength(15);
        assertNotNull(fifteenCharTitles);
        assertFalse(fifteenCharTitles.isEmpty());
        fifteenCharTitles.forEach(novel -> System.out.println(novel.getTitle()));
    }
}
