/*
    @ author : Kwanele Dladla
 */

import org.example.Novel;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class NovelTest
{
    @Test
    public void NovelTestA() {
        Novel novel = new Novel("Title", "Author", 2000);

        assertEquals("Title", novel.getTitle());
        assertEquals("Author", novel.getAuthorName());
        assertEquals(2000, novel.getYearPublished());
    }
}
