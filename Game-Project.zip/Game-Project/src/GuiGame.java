import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;

/*
@ author : Kwanele Dladla
@ Project:
@version 11.09.10
 */

public class GuiGame extends JFrame
{

    private static JTextField guessField;
    private static JLabel scoreLabel;
    private static JLabel feedbackLabel;
    private static JTextArea historyArea;
    private int targetNumber;
    private int score;

    // Constructor to set up the GUI
    public GuiGame(final JTextField guessField, final JLabel scoreLabel, final JLabel feedbackLabel, final JTextArea historyArea)
    {
        GuiGame.guessField = guessField;
        GuiGame.scoreLabel = scoreLabel;
        GuiGame.feedbackLabel = feedbackLabel;
        GuiGame.historyArea = historyArea;
        setTitle("Guess the Number Game");
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize the target number and score
        targetNumber = (int) (Math.random() * 100) + 1;
        score = 0;

        // Add components
        initUI();
    }

    // Method to initialize the UI components
    private void initUI()
    {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(245, 245, 245)); // Light gray background
        getContentPane().add(panel);

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setBackground(new Color(70, 130, 180));
        topPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("Guess a number between 1 and 100");
        titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        topPanel.add(titleLabel);

        panel.add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(new Color(245, 245, 245));
        centerPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        guessField = new JTextField(10);
        guessField.setMaximumSize(new Dimension(200, 30));
        guessField.setFont(new Font("Serif", Font.PLAIN, 18));
        guessField.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(guessField);

        // Add ActionListener to JTextField for Enter key submission
        guessField.addActionListener(e -> checkGuess());

        centerPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer

        JButton button = new JButton("Submit Guess");
        button.setFont(new Font("Serif", Font.BOLD, 18));
        button.setBackground(new Color(30, 144, 255)); // Dodger blue background
        button.setForeground(Color.WHITE); // White text color
        button.setFocusPainted(false);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.addActionListener(event -> checkGuess());
        centerPanel.add(button);

        centerPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer

        scoreLabel = new JLabel("Score: " + score);
        scoreLabel.setFont(new Font("Serif", Font.BOLD, 18));
        scoreLabel.setForeground(new Color(70, 130, 180)); // Steel blue text color
        scoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(scoreLabel);

        centerPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer

        feedbackLabel = new JLabel("");
        feedbackLabel.setFont(new Font("Serif", Font.PLAIN, 16));
        feedbackLabel.setForeground(new Color(255, 69, 0)); // Red text color
        feedbackLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(feedbackLabel);

        panel.add(centerPanel, BorderLayout.CENTER);

        historyArea = new JTextArea();
        historyArea.setEditable(false);
        historyArea.setFont(new Font("Serif", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(historyArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Guess History"));
        scrollPane.setPreferredSize(new Dimension(400, 120));
        panel.add(scrollPane, BorderLayout.SOUTH);

        // Add the menu bar
        createMenuBar();
    }

    // Method to create the menu bar
    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu optionsMenu = new JMenu("Options");
        JMenuItem howToPlayItem = new JMenuItem("How to Play");
        JMenuItem sendFeedbackItem = new JMenuItem("Send Feedback");
        JMenuItem restartGameItem = new JMenuItem("Restart Game");
        JMenuItem exitItem = new JMenuItem("Exit");

        howToPlayItem.addActionListener(event -> JOptionPane.showMessageDialog(null,
                "Instructions:\n" +
                        "1. Enter a number between 1 and 100 in the text field.\n" +
                        "2. Click 'Submit Guess' to check your guess.\n" +
                        "3. If your guess is too low or too high, you will receive feedback.\n" +
                        "4. Keep guessing until you find the correct number.\n" +
                        "5. Your score will be displayed and updated after each guess.\n" +
                        "6. You can restart the game or exit from the 'Options' menu.",
                "How to Play", JOptionPane.INFORMATION_MESSAGE));

        sendFeedbackItem.addActionListener(event -> {
            String feedback = JOptionPane.showInputDialog(null, "Enter your feedback:", "Send Feedback", JOptionPane.INFORMATION_MESSAGE);
            if (feedback != null && !feedback.isEmpty()) {
                writeFeedbackToFile(feedback);
                JOptionPane.showMessageDialog(null, "Thank you for your feedback!", "Feedback Received", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        restartGameItem.addActionListener(event -> resetGame());

        exitItem.addActionListener(event -> System.exit(0));

        optionsMenu.add(howToPlayItem);
        optionsMenu.add(sendFeedbackItem);
        optionsMenu.addSeparator();
        optionsMenu.add(restartGameItem);
        optionsMenu.add(exitItem);

        menuBar.add(optionsMenu);

        setJMenuBar(menuBar);
    }

    // Method to check the user's guess
    private void checkGuess() {
        try {
            int guess = Integer.parseInt(guessField.getText());
            if (guess < 1 || guess > 100) {
                feedbackLabel.setText("Please enter a number between 1 and 100.");
            } else if (guess < targetNumber) {
                feedbackLabel.setText("Too low! Try again.");
                score++;
                updateScore();
                updateHistory(guess, "Too low");
            } else if (guess > targetNumber) {
                feedbackLabel.setText("Too high! Try again.");
                score++;
                updateScore();
                updateHistory(guess, "Too high");
            } else {
                feedbackLabel.setText("Correct! The number was " + targetNumber);
                score++;
                updateScore();
                updateHistory(guess, "Correct");
            }
        } catch (NumberFormatException e) {
            feedbackLabel.setText("Please enter a valid number.");
        }
    }

    // Method to update the score
    private void updateScore() {
        scoreLabel.setText("Score: " + score);
    }

    // Method to update the guess history
    private void updateHistory(int guess, String result) {
        historyArea.append("Guessed " + guess + ": " + result + "\n");
    }

    // Method to reset the game
    private void resetGame() {
        targetNumber = (int) (Math.random() * 100) + 1;
        guessField.setText("");
        feedbackLabel.setText("");
        score = 0;
        updateScore();
        historyArea.setText("");
    }

    // Method to write feedback to a text file
    private void writeFeedbackToFile(String feedback) {
        try (FileWriter writer = new FileWriter("feedback.txt", true)) {
            writer.write(feedback + "\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing feedback to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GuiGame ex = new GuiGame(guessField, scoreLabel, feedbackLabel, historyArea);
            ex.setVisible(true);
        });
    }
}
